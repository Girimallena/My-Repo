#include <stdio.h>
#include<time.h>
#include <stdlib.h>
#define size 20
int main(int args, char** argv) {
//    int srand48(void);
//    double drand48(void);
   srand48((unsigned int)time(NULL));
   int size1;
   printf("Enter array Size: ");
   scanf("%d",&size1);
   double array [size1];
   int i,j,k;
   for (i=0; i<size1; i++) {
       array[i] = drand48();
       printf("%lf \t",array[i]);
   }
   printf("\n Unsorted Array \n");
   for (k=0; k<size1; k++){
	    printf("%lf ",array[k]);
	}
    
    printf("\n") ;
    int currLoc;
    double temp;
	for (j=1; j<size1; j++){
	    currLoc = j;
	    printf("CurrLoc %d\n",currLoc);
	    while (currLoc > 0 && (array[currLoc-1] > array[currLoc])){
		printf("%lf %lf \t ",array[currLoc],array[currLoc-1]);
        temp = array[currLoc];
		array[currLoc] = array[currLoc-1];
		array[currLoc-1] = temp;
		printf("\n");
		currLoc--;
	    }
	}
	
	
		
	// Display
	printf("\nSorted array is: ");
	printf("[");
	for (int k=0; k<size1; k++){
	    printf("%lf ",array[k]);
	}
        printf("]\n");

    return 0;
}	
	
